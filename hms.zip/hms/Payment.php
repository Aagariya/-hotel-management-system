<!DOCTYPE html>
<html lang="en">
<head>
	<title>Online Hotel.Com</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	<link href="css/style.css"rel="stylesheet"/>
	<link href="https://fonts.googleapis.com/css?family=Abril+Fatface" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<body style="margin-top:50px;">
	<?php
	include('Menu Bar.php');
	?>
	<div class="container-fluid text-center">
		<div class="container"> 
			<br><br>
			<h2>Please choose payment option</h2><hr>
			<div class="row"align="center">
				<!--map Start Here--> 
				<!--Map Close Here-->
				<div class="col-sm-2">
					<a href="https://www.apple.com/apple-pay/"><img src="image/payment/apple-pay.png"width="60px;"height="50px;"style="margin-top:15px;"></a>
				</div>
				
				<div class="col-sm-2">
					<a href="https://pay.google.com/intl/en_in/about/?gclid=CjwKCAiA9aKQBhBREiwAyGP5lWc3z8jlp5GORHP3lCj6CgCKNlmEzQ0-MruWJMuk53OD3B3XWL0A2xoCOuwQAvD_BwE&gclsrc=aw.ds"><img src="image/payment/google-pay.png"width="60px;"height="50px;"style="margin-top:15px;"></a>
				</div>
				
				<div class="col-sm-2">
					<a href="https://www.paypal.com/in/webapps/mpp/home?kid=p39982196119&gclid=CjwKCAiA9aKQBhBREiwAyGP5lcJxx9n2vEKpDYP1jB7xMXcXIX_ArZYmz-50n2_bw2lZeDsm5dgRAhoCbQ8QAvD_BwE&gclsrc=aw.ds"><img src="image/payment/paypal.png"width="60px;"height="50px;"style="margin-top:15px;"></a>
				</div>
				
			</div><br><br>
		</div>
	</div>
	<?php
	include('Footer.php')
	?>
</body>
</html>
